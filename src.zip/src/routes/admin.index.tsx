import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import manosPostre from "@/assets/manos-postre.jpg";
import { CounterStore } from "@/features/counter-store/CounterStore";
import { InstallPrompt } from "@/components/InstallPrompt";
import { RequireAdmin } from "@/features/admin/RequireAdmin";

export const Route = createFileRoute("/admin/")({
  component: () => (
    <RequireAdmin>
      <Home />
    </RequireAdmin>
  ),
});

function Home() {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  // Blindaje de hidratación: 
  // Garantiza que ni CounterStore ni InstallPrompt se ejecuten en el servidor
  if (!isClient) return null;

  return (
    <main className="min-h-screen bg-crema">
      <header className="mx-auto max-w-6xl px-6 pt-12 pb-8 text-center">
        <h1 className="mt-3 flex justify-center">
          <img
            src="/titulo_majito.png"
            alt="Majito Cake"
            width={908}
            height={381}
            className="h-auto w-full max-w-2xl"
          />
        </h1>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-8 px-6 pb-12 md:grid-cols-2">
        <div className="order-2 md:order-1">
          <p className="mt-4 text-lg leading-relaxed text-foreground/85 text-justify hyphens-auto">
            Detrás de Majito hay un sueño que nació en el corazón de Tuxpan,
            Veracruz. Guiados por la frescura y la innovación de una joven promesa
            de la gastronomía, convertimos del arte de la repostería en una
            experiencia de amor y emociones a través nuestras creaciones.
          </p>
        </div>
        <div className="order-1 overflow-hidden rounded-3xl shadow-lg md:order-2">
          <img
            src={manosPostre}
            alt="Manos de repostera decorando un postre artesanal en Majito Cake"
            width={1536}
            height={1024}
            className="h-full w-full object-cover"
          />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-12 flex justify-center">
        <Link
          to="/rastreo"
          className="flex flex-col items-center gap-3 p-4 hover:scale-105 transition-transform duration-300 cursor-pointer"
        >
          <img 
            src="/rastreo.svg"
            alt="Rastrear mi pedido" 
            className="w-16 h-16 object-contain drop-shadow-md"
          />
          <span className="font-semibold text-gray-700 text-lg">
            Rastrear mi pedido
          </span>
        </Link>
      </section>

      <section className="mx-auto max-w-6xl px-6 pb-16">
        <div className="mb-6 flex items-end justify-between">
          <h2 className="text-3xl font-bold text-shocking md:text-4xl">Nuestros productos</h2>
          <Link to="/mostrador" className="text-sm font-semibold text-mocha underline decoration-shocking underline-offset-4">
            Ver mostrador completo →
          </Link>
        </div>
        
        <CounterStore />
      </section>

      <footer className="border-t border-mocha/20 bg-sunset/40 py-6 text-center text-xs text-foreground/70">
        <p>Cero comisiones bancarias · Efectivo · SPEI · CoDi</p>
        <p className="mt-1">
          <Link to="/cocina" className="underline decoration-shocking underline-offset-4">
            Entrar a la cocina (KDS)
          </Link>
        </p>
        <p className="mt-1">
          <Link to="/admin" className="underline decoration-shocking underline-offset-4">
            Admin / Configuración
          </Link>
        </p>
      </footer>
      <InstallPrompt />
    </main>
  );
}